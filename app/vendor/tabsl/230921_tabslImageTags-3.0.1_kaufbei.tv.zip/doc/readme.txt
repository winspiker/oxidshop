==Title==
tabslImageTags

==Author==
Tobias Merkl

==Prefix==
tabsl

==Version==
3.0.1

==Link==
https://oxid-module.eu

==Mail==
support@oxid-module.eu

==Installation==
https://oxid-module.eu/dokumentation/tabsl-imagetags/

==Extend==
---
