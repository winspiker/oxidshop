-- tabslImageTags 3.0.1
ALTER TABLE oxcategories ADD tabsl_imagetag_thumb VARCHAR(255);
ALTER TABLE oxcategories ADD tabsl_imagetag_icon VARCHAR(255);
ALTER TABLE oxarticles ADD tabsl_imagetag1 VARCHAR(255);
ALTER TABLE oxarticles ADD tabsl_imagetag2 VARCHAR(255);
ALTER TABLE oxarticles ADD tabsl_imagetag3 VARCHAR(255);
ALTER TABLE oxarticles ADD tabsl_imagetag4 VARCHAR(255);
ALTER TABLE oxarticles ADD tabsl_imagetag5 VARCHAR(255);
ALTER TABLE oxarticles ADD tabsl_imagetag6 VARCHAR(255);
ALTER TABLE oxarticles ADD tabsl_imagetag7 VARCHAR(255);
#ALTER TABLE oxarticles ADD tabsl_imagetag8 VARCHAR(255);
#ALTER TABLE oxarticles ADD tabsl_imagetag9 VARCHAR(255);
#ALTER TABLE oxarticles ADD tabsl_imagetag10 VARCHAR(255);
#ALTER TABLE oxarticles ADD tabsl_imagetag11 VARCHAR(255);
#ALTER TABLE oxarticles ADD tabsl_imagetag12 VARCHAR(255);
